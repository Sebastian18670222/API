<?php

namespace App\Http\Controllers;

use App\Models\Alumnos;
use Illuminate\Http\Request;

class AlumnosController extends Controller
{
    
    public function showAllAlumnos()
    {
        return response()->json(Alumnos::all());
    }

    public function showOneAlumno($ctrl)
    {
        $alumno = Alumnos::where('no_control',$ctrl)->first();
        return response()->json($alumno);
    }

    public function create(Request $request)
    {
        $alumno = Alumnos::create($request->all());
        return response()->json($alumno, 201);
    }

    public function delete($ctrl)
    {
        Alumnos::where('no_control',$ctrl)->delete();
        return response('Deleted Successfully', 200);
    }
}