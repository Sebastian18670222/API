<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('alumnos',  ['uses' => 'AlumnosController@showAllAlumnos']); //todos

$router->get('alumnos/{ctrl}', ['uses' => 'AlumnosController@showOneAlumno']); //obtener uno por no_control

$router->post('alumnos', ['uses' => 'AlumnosController@create']); //crear un nuevo alumno

$router->delete('alumnos/{ctrl}', ['uses' => 'AlumnosController@delete']); //eliminar un alumno
